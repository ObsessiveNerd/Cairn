
Better UI 
     v2.0



-= Legal Notice =-

Copyright (C) 2017 Thera Bytes GmbH - All Rights Reserved
Created by Salomon Zwecker
This Unity Asset can only be used under the standard Unity Asset Store End User License Agreement
A Copy of the EULA APPENDIX 1 is available at http://unity3d.com/company/legal/as_terms



-= Documentation =-

The latest Documentation (and earlier documentations) can be viewed here:
http://documentation.therabytes.de/better-ui/



-= Contact =-

If you have any trouble getting the Asset running, 
if you found a bug 
or if you have a suggestion, 
please leave a note in the forum thread:
https://forum.unity3d.com/threads/better-ui.453808/

If you find Better UI useful, we would be happy if you would leave us a 5-Star rating.
https://www.assetstore.unity3d.com/en/#!/content/79031



-= Text Mesh Pro Support =-

If you are using TextMeshPro and you would like to also use the Better-TextMeshPro features, 
you have to install the Better UI Textmesh Pro package additionally.
you can download it here: http://downloads.therabytes.de/BetterUI_2.0_TMP.unitypackage
