﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheraBytes.BetterUi
{
    public interface IScreenConfigConnection
    {
        string ScreenConfigName { get; set; }
    }
}
